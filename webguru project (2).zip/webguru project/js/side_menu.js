function side_menu_item(){
    document.write("<p>item_1</p>");
    document.write("<p>item_1</p>");
    document.write("<p>item_1</p>");
    document.write("<p>item_1</p>");
    document.write("<p>item_1</p>");
    document.write("<p>item_1</p>");
}